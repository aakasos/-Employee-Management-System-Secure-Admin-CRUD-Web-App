"""Automated tests: authentication, validation and full CRUD cycle.
Run with:  python -m unittest discover -s tests -v
"""
import os
import re
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import create_app  # noqa: E402

VALID = {"name": "Priya Sharma", "email": "priya@example.com", "phone": "9876543210",
         "department": "Engineering", "position": "Backend Developer",
         "salary": "65000", "join_date": "2024-01-15"}


class EmployeeAppTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        app = create_app({"TESTING": True,
                          "DATABASE": os.path.join(self.tmp.name, "test.db"),
                          "ADMIN_USERNAME": "admin", "ADMIN_PASSWORD": "Admin@123"})
        self.client = app.test_client()

    def tearDown(self):
        self.tmp.cleanup()

    # helpers
    def token(self, url="/login"):
        html = self.client.get(url).get_data(as_text=True)
        return re.search(r'name="_csrf" value="([^"]+)"', html).group(1)

    def login(self, pw="Admin@123"):
        return self.client.post("/login", data={"username": "admin", "password": pw,
                                                "_csrf": self.token()}, follow_redirects=True)

    def create(self, **over):
        return self.client.post("/employees/new",
                                data={**VALID, **over, "_csrf": self.token("/employees/new")})

    # tests
    def test_dashboard_requires_login(self):
        r = self.client.get("/dashboard")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])

    def test_login_success_and_failure(self):
        self.assertIn(b"Invalid username or password", self.login("wrong").data)
        self.assertIn(b"Welcome back", self.login().data)

    def test_post_without_csrf_is_rejected(self):
        r = self.client.post("/login", data={"username": "admin", "password": "x"})
        self.assertEqual(r.status_code, 400)

    def test_full_crud_cycle(self):
        self.login()
        r = self.create()                                           # CREATE
        self.assertEqual(r.status_code, 302)
        self.assertIn(b"Priya Sharma", self.client.get("/dashboard").data)
        self.assertIn(b"Backend Developer", self.client.get("/employees/1").data)   # READ
        r = self.client.post("/employees/1/edit",                    # UPDATE
                             data={**VALID, "position": "Tech Lead",
                                   "_csrf": self.token("/employees/1/edit")},
                             follow_redirects=True)
        self.assertIn(b"Employee updated successfully", r.data)
        self.assertIn(b"Tech Lead", r.data)
        r = self.client.post("/employees/1/delete",                  # DELETE
                             data={"_csrf": self.token("/dashboard")}, follow_redirects=True)
        self.assertIn(b"Employee deleted", r.data)
        self.assertEqual(self.client.get("/employees/1").status_code, 404)

    def test_validation_rejects_bad_input(self):
        self.login()
        bad_values = {"name": "12345", "email": "not-an-email", "phone": "12345",
                      "department": "Hacking", "salary": "-5", "join_date": "2999-01-01"}
        for field, bad in bad_values.items():
            with self.subTest(field=field):
                r = self.create(**{field: bad})
                self.assertEqual(r.status_code, 400)
                self.assertIn(b'class="error"', r.data)

    def test_duplicate_email_rejected(self):
        self.login()
        self.create()
        r = self.create()
        self.assertEqual(r.status_code, 400)
        self.assertIn(b"already exists", r.data)

    def test_sql_injection_attempt_is_harmless(self):
        self.login()
        r = self.client.get("/dashboard?q=' OR 1=1; DROP TABLE employees;--")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.client.get("/dashboard").status_code, 200)

    def test_logout_ends_session(self):
        self.login()
        self.client.post("/logout", data={"_csrf": self.token("/dashboard")})
        self.assertEqual(self.client.get("/dashboard").status_code, 302)


if __name__ == "__main__":
    unittest.main(verbosity=2)
