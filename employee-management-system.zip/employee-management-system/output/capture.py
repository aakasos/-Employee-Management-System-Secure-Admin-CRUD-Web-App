"""Seeds demo data and captures the screenshots stored in /output."""
import os, sys, threading, time, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import create_app
from playwright.sync_api import sync_playwright

OUT = os.path.dirname(os.path.abspath(__file__))
db = os.path.join(tempfile.mkdtemp(), "demo.db")
app = create_app({"DATABASE": db})
threading.Thread(target=lambda: app.run(port=5055, use_reloader=False), daemon=True).start()
time.sleep(1.5)

DEMO = [("Priya Sharma","priya@example.com","9876543210","Engineering","Backend Developer","65000","2024-01-15"),
        ("Arjun Kumar","arjun@example.com","9123456780","HR","HR Manager","52000","2023-06-01"),
        ("Meena Iyer","meena@example.com","9988776655","Finance","Accountant","48000","2022-09-12"),
        ("Rahul Verma","rahul@example.com","8899001122","Sales","Sales Executive","41000","2024-03-20")]

def shot(page, name):
    page.screenshot(path=os.path.join(OUT, name), full_page=True)
    print("saved", name)

with sync_playwright() as p:
    b = p.chromium.launch()
    page = b.new_page(viewport={"width": 1200, "height": 760})
    base = "http://127.0.0.1:5055"
    page.goto(base + "/login"); shot(page, "01_login.png")
    page.fill("input[name=username]", "admin"); page.fill("input[name=password]", "wrong")
    page.click("main button[type=submit]"); shot(page, "02_login_failed.png")
    page.fill("input[name=username]", "admin"); page.fill("input[name=password]", "Admin@123")
    page.click("main button[type=submit]"); page.wait_for_url("**/dashboard")
    for d in DEMO:
        page.goto(base + "/employees/new")
        for k, v in zip(["name","email","phone","department","position","salary","join_date"], d):
            (page.select_option if k == "department" else page.fill)(f"[name={k}]", v)
        page.click("main button[type=submit]"); page.wait_for_url("**/dashboard")
    shot(page, "03_dashboard.png")
    page.goto(base + "/employees/new")
    page.fill("[name=name]", "R2"); page.fill("[name=email]", "bad-email"); page.fill("[name=phone]", "123")
    page.fill("[name=salary]", "-10"); page.click("main button[type=submit]"); shot(page, "04_validation_errors.png")
    page.goto(base + "/employees/1/edit"); shot(page, "05_edit_form.png")
    page.goto(base + "/employees/1"); shot(page, "06_employee_detail.png")
    b.close()
